@echo off
chcp 65001 >nul
echo ============================================================================
echo   DESPLIEGUE AUTOMATICO - ALERTA DESAPARECIDOS PNP (WEB + iOS + ANDROID)
echo ============================================================================
echo.
echo [1/5] Limpiando cache y obteniendo dependencias de Flutter...
call flutter clean
call flutter pub get

echo.
echo [2/5] Compilando version Web optimizada (compatible con iPhone Safari)...
call flutter build web --release

echo.
echo [3/5] Desplegando indices y reglas de seguridad en Firebase...
call firebase deploy --only firestore:indexes,firestore:rules,storage

echo.
echo [4/5] Publicando aplicacion Web en produccion (pnpalerta.web.app)...
call firebase deploy --only hosting

echo.
echo [5/5] Guardando cambios y subiendo a GitHub (shamirdhc/alerta_desaparecidos)...
if exist bash.exe.stackdump del /f /q bash.exe.stackdump
git add .
git commit -m "fix(ios-web-security): solucion login loop iPhone, reglas Firebase y optimizacion WebP/3G"
git push origin main

echo.
echo ============================================================================
echo   PROCESO COMPLETADO EXITOSAMENTE
echo ============================================================================
pause
