#!/usr/bin/env bash
# =============================================================================
# Script Maestro de Parches Multiplataforma + Solución Definitiva Login iPhone
# Repositorio: https://github.com/shamirdhc/alerta_desaparecidos
# Proyecto Firebase: alerta-desaparecidos-pnp / https://pnpalerta.web.app
# Uso: chmod +x aplicar_parches_pnpalerta.sh && ./aplicar_parches_pnpalerta.sh
# =============================================================================
set -euo pipefail

echo "[1/10] Creando respaldos preventivos en .backup_auditoria/ y limpiando archivos basura..."
mkdir -p .backup_auditoria ios/Runner web lib/helpers lib/presentation/screens lib/presentation/police/view_models lib/data/data_sources lib/domain/entities
for f in lib/injection.dart lib/main.dart lib/firebase_options.dart lib/helpers/database_helpers.dart lib/presentation/screens/registration_screen.dart lib/presentation/screens/otp_screen.dart lib/domain/entities/desaparecido.dart lib/data/data_sources/desaparecido_remote_data_source.dart lib/presentation/police/view_models/add_missing_view_model.dart firebase.json web/index.html web/manifest.json ios/Runner/Info.plist; do
  if [ -f "$f" ]; then
    cp "$f" ".backup_auditoria/$(basename "$f").bak"
  fi
done
rm -f bash.exe.stackdump

echo "[2/10] Aplicando fix de authDomain para Safari iPhone (ITP) en lib/firebase_options.dart..."
cat << 'EOF' > lib/firebase_options.dart
// File generated and hardened for Multiplatform + iOS Safari ITP compatibility.
// ignore_for_file: type=lint
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return ios;
      case TargetPlatform.windows:
        return windows;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  /// En iPhone (Safari / WebKit ITP), si authDomain difiere del dominio actual
  /// (ej. pnpalerta.web.app vs alerta-desaparecidos-pnp.firebaseapp.com),
  /// Safari bloquea sessionStorage/cookies de terceros y devuelve al usuario al Login.
  static String get _resolvedWebAuthDomain {
    if (kIsWeb) {
      final host = Uri.base.host;
      if (host.endsWith('.web.app') || host.endsWith('.firebaseapp.com')) {
        return host;
      }
    }
    return 'alerta-desaparecidos-pnp.firebaseapp.com';
  }

  static FirebaseOptions get web => FirebaseOptions(
        apiKey: 'AIzaSyD0hbcfgvjzAKyNw0k81_-3y1wGbX3rogM',
        appId: '1:75698715605:web:a77a01a49471b69d151b5c',
        messagingSenderId: '75698715605',
        projectId: 'alerta-desaparecidos-pnp',
        authDomain: _resolvedWebAuthDomain,
        storageBucket: 'alerta-desaparecidos-pnp.firebasestorage.app',
      );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBw_kcfAG4V4TDJ3T-yhV1MbP8jKGWy2eM',
    appId: '1:75698715605:android:0457d3e14a710c5c151b5c',
    messagingSenderId: '75698715605',
    projectId: 'alerta-desaparecidos-pnp',
    storageBucket: 'alerta-desaparecidos-pnp.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyCyMnR9Jdkd6xHYrNMcdB2w_WOysCMp3wQ',
    appId: '1:75698715605:ios:99a336d9f0e533db151b5c',
    messagingSenderId: '75698715605',
    projectId: 'alerta-desaparecidos-pnp',
    storageBucket: 'alerta-desaparecidos-pnp.firebasestorage.app',
    iosBundleId: 'com.shamirdhc.alertaDesaparecidos',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyD0hbcfgvjzAKyNw0k81_-3y1wGbX3rogM',
    appId: '1:75698715605:web:25fe2de4fc75b680151b5c',
    messagingSenderId: '75698715605',
    projectId: 'alerta-desaparecidos-pnp',
    authDomain: 'alerta-desaparecidos-pnp.firebaseapp.com',
    storageBucket: 'alerta-desaparecidos-pnp.firebasestorage.app',
  );
}
EOF

echo "[3/10] Aplicando AuthGateScreen y persistencia iOS en lib/main.dart..."
cat << 'EOF' > lib/main.dart
import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'firebase_options.dart';
import 'package:alerta_desaparecidos/injection.dart' as di;
import 'package:alerta_desaparecidos/common/styles/app_theme.dart';
import 'package:alerta_desaparecidos/presentation/citizen/screens/citizen_home_screen.dart';
import 'package:alerta_desaparecidos/presentation/common/loading_screen.dart';
import 'package:alerta_desaparecidos/presentation/police/screens/police_home_screen.dart';
import 'package:alerta_desaparecidos/presentation/police/view_models/add_missing_view_model.dart';
import 'package:alerta_desaparecidos/presentation/police/view_models/manage_missing_view_model.dart';
import 'package:alerta_desaparecidos/presentation/citizen/view_models/view_missing_view_model.dart';
import 'package:alerta_desaparecidos/presentation/screens/registration_screen.dart';

const String _kRecaptchaSiteKey = String.fromEnvironment(
  'RECAPTCHA_ENTERPRISE_SITE_KEY',
  defaultValue: '',
);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  // 1. FIX CRÍTICO PARA iPHONE (Safari / WebKit ITP y Modo Privado):
  // Garantiza persistencia de sesión en iOS Web y consume cualquier redirect pendiente
  if (kIsWeb) {
    try {
      await FirebaseAuth.instance.setPersistence(Persistence.LOCAL);
    } catch (_) {
      // Fallback para Safari en Navegación Privada en iPhone (donde indexedDB está restringido)
      try {
        await FirebaseAuth.instance.setPersistence(Persistence.SESSION);
      } catch (_) {}
    }
    try {
      await FirebaseAuth.instance.getRedirectResult();
    } catch (e) {
      debugPrint('[iOS Web Redirect Info] $e');
    }
  }

  // 2. Activar Firebase App Check si está configurado
  if (!kIsWeb || _kRecaptchaSiteKey.isNotEmpty) {
    try {
      await FirebaseAppCheck.instance.activate(
        webProvider: ReCaptchaEnterpriseProvider(_kRecaptchaSiteKey),
        androidProvider:
            kDebugMode ? AndroidProvider.debug : AndroidProvider.playIntegrity,
        appleProvider:
            kDebugMode ? AppleProvider.debug : AppleProvider.appAttest,
      );
    } catch (e) {
      debugPrint('[AppCheck] Aviso de inicialización: $e');
    }
  }

  // 3. Habilitar caché offline en Firestore (con fallback seguro para Safari iOS)
  try {
    FirebaseFirestore.instance.settings = const Settings(
      persistenceEnabled: true,
      cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
    );
  } catch (_) {}

  // 4. Manejo global de errores (Error Boundary)
  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.presentError(details);
  };
  PlatformDispatcher.instance.onError = (Object error, StackTrace stack) {
    debugPrint('[AsyncError] $error\n$stack');
    return true;
  };

  di.init();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => di.locator<AddMissingViewModel>()),
        ChangeNotifierProvider(create: (_) => di.locator<ManageMissingViewModel>()),
        ChangeNotifierProvider(create: (_) => di.locator<ViewMissingViewModel>()),
      ],
      child: MaterialApp(
        title: 'Alerta Desaparecidos PNP',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        supportedLocales: const [
          Locale('es', 'ES'),
          Locale('en', 'US'),
        ],
        locale: const Locale('es', 'ES'),
        home: const AuthGateScreen(),
        routes: {
          '/registration': (context) => const RegistrationScreen(),
          '/registro': (context) => const RegistrationScreen(),
          '/citizen_home': (context) => const CitizenHomeScreen(),
          '/ciudadano_home': (context) => const CitizenHomeScreen(),
          '/police_home': (context) => const PoliceHomeScreen(),
          '/policia_home': (context) => const PoliceHomeScreen(),
        },
      ),
    );
  }
}

/// Widget guardián de sesión que resuelve el bug de iPhone donde el usuario
/// era devuelto a RegistrationScreen después de iniciar sesión.
/// Causa original: main.dart sólo revisaba `claims['role']` (que era null) y
/// re-ejecutaba `getIdTokenResult(true)` en cada cambio de métricas de pantalla en iOS.
class AuthGateScreen extends StatefulWidget {
  const AuthGateScreen({super.key});

  @override
  State<AuthGateScreen> createState() => _AuthGateScreenState();
}

class _AuthGateScreenState extends State<AuthGateScreen> {
  String? _cachedUid;
  Future<String>? _roleFuture;

  Future<String> _resolveAndEnsureUserRole(User user) async {
    final prefs = await SharedPreferences.getInstance();

    // 1. Revisar Custom Claims en el token JWT (sin forzar red si no es necesario)
    try {
      final tokenResult = await user.getIdTokenResult(false);
      final claimRole = tokenResult.claims?['role']?.toString();
      if (claimRole == 'police' || claimRole == 'superadmin') {
        await prefs.setString('cached_role_${user.uid}', 'police');
        return 'police';
      }
      if (claimRole == 'citizen') {
        await prefs.setString('cached_role_${user.uid}', 'citizen');
        return 'citizen';
      }
    } catch (_) {}

    // 2. Revisar colección 'policias' por UID o por número de teléfono
    try {
      final policeDocByUid = await FirebaseFirestore.instance
          .collection('policias')
          .doc(user.uid)
          .get();
      if (policeDocByUid.exists) {
        await prefs.setString('cached_role_${user.uid}', 'police');
        return 'police';
      }

      if (user.phoneNumber != null && user.phoneNumber!.isNotEmpty) {
        final policeQuery = await FirebaseFirestore.instance
            .collection('policias')
            .where('telefono', isEqualTo: user.phoneNumber)
            .limit(1)
            .get();
        if (policeQuery.docs.isNotEmpty) {
          await prefs.setString('cached_role_${user.uid}', 'police');
          return 'police';
        }
      }
    } catch (_) {}

    // 3. Revisar o auto-crear perfil en colección 'ciudadanos' (Evita Race Condition en iPhone)
    try {
      final citizenRef =
          FirebaseFirestore.instance.collection('ciudadanos').doc(user.uid);
      final citizenDoc = await citizenRef.get();
      if (citizenDoc.exists) {
        await prefs.setString('cached_role_${user.uid}', 'citizen');
        return 'citizen';
      }

      // Si el usuario ya se autenticó con Firebase Auth (OTP o Google en iPhone)
      // pero la escritura de otp_screen aún está en vuelo o fue interrumpida por Safari,
      // aseguramos el documento automáticamente en lugar de devolverlo al Login:
      await citizenRef.set({
        'uid': user.uid,
        'telefono': user.phoneNumber ?? '',
        'email': user.email ?? '',
        'rol': 'ciudadano',
        'fecha_registro': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      await prefs.setString('cached_role_${user.uid}', 'citizen');
      return 'citizen';
    } catch (_) {
      // Si la red falla momentáneamente en iPhone tras el login, usar rol cacheado o 'citizen'
      return prefs.getString('cached_role_${user.uid}') ?? 'citizen';
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting &&
            _cachedUid == null) {
          return const LoadingScreen();
        }

        final user = snapshot.data ?? FirebaseAuth.instance.currentUser;
        if (user == null) {
          _cachedUid = null;
          _roleFuture = null;
          return const RegistrationScreen();
        }

        // Memoizar el Future por UID para que cuando iOS cierre el teclado o cambie
        // la barra de Safari no se dispare un bucle de recarga al Login
        if (_cachedUid != user.uid || _roleFuture == null) {
          _cachedUid = user.uid;
          _roleFuture = _resolveAndEnsureUserRole(user);
        }

        return FutureBuilder<String>(
          future: _roleFuture,
          builder: (context, roleSnapshot) {
            if (roleSnapshot.connectionState == ConnectionState.waiting) {
              return const LoadingScreen();
            }
            final role = roleSnapshot.data ?? 'citizen';
            if (role == 'police') {
              return const PoliceHomeScreen();
            }
            return const CitizenHomeScreen();
          },
        );
      },
    );
  }
}
EOF

echo "[4/10] Actualizando lib/presentation/screens/registration_screen.dart y otp_screen.dart (Fix Login Loop iPhone)..."
cat << 'EOF' > lib/presentation/screens/registration_screen.dart
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'otp_screen.dart';

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key});

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final TextEditingController _phoneController = TextEditingController();
  ConfirmationResult? _webConfirmationResult;
  String? _errorMessage;
  bool _isRegistering = false;

  @override
  void dispose() {
    _phoneController.dispose();
    super.dispose();
  }

  Future<bool> _isNumberVetoed(String phoneNumber) async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('vetados')
          .where('numero_telefono', isEqualTo: phoneNumber)
          .limit(1)
          .get();
      return snapshot.docs.isNotEmpty;
    } catch (_) {
      // Si las reglas de Firestore bloquean lectura anónima o falla la red, no bloquear el acceso
      return false;
    }
  }

  Future<void> _registerUser(String phoneNumber) async {
    try {
      // Soporte específico para Web (incluyendo Safari en iPhone) vs Nativo (iOS/Android)
      if (kIsWeb) {
        _webConfirmationResult =
            await FirebaseAuth.instance.signInWithPhoneNumber(phoneNumber);
        if (!mounted) return;
        setState(() => _isRegistering = false);
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => OTPScreen(
              phoneNumber: phoneNumber,
              verificationId: _webConfirmationResult!.verificationId,
              webConfirmationResult: _webConfirmationResult,
            ),
          ),
        );
        return;
      }

      await FirebaseAuth.instance.verifyPhoneNumber(
        phoneNumber: phoneNumber,
        timeout: const Duration(seconds: 60),
        verificationCompleted: (PhoneAuthCredential credential) async {
          try {
            await FirebaseAuth.instance.signInWithCredential(credential);
          } catch (_) {}
        },
        verificationFailed: (FirebaseAuthException e) {
          if (!mounted) return;
          setState(() {
            _errorMessage =
                'Error al enviar el código de verificación: ${e.message ?? e.code}';
            _isRegistering = false;
          });
        },
        codeSent: (String verificationId, int? resendToken) {
          if (!mounted) return;
          setState(() => _isRegistering = false);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => OTPScreen(
                phoneNumber: phoneNumber,
                verificationId: verificationId,
              ),
            ),
          );
        },
        codeAutoRetrievalTimeout: (String verificationId) {
          if (!mounted) return;
          setState(() => _isRegistering = false);
        },
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _errorMessage = 'Error durante el inicio de sesión: $e';
        _isRegistering = false;
      });
    }
  }

  Future<void> _registerOrLogin() async {
    final rawPhone = _phoneController.text.replaceAll(RegExp(r'\D'), '');
    if (rawPhone.length != 9) {
      setState(() {
        _errorMessage = 'Ingresa un número de celular válido de 9 dígitos.';
      });
      return;
    }

    setState(() {
      _errorMessage = null;
      _isRegistering = true;
    });

    final String phoneNumber = '+51$rawPhone';

    if (await _isNumberVetoed(phoneNumber)) {
      if (!mounted) return;
      setState(() {
        _errorMessage =
            'El número de teléfono proporcionado ha sido restringido por infringir los términos del servicio.';
        _isRegistering = false;
      });
      return;
    }

    await _registerUser(phoneNumber);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      // Permite cerrar el teclado en iPhone al tocar fuera del campo de texto
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: AppBar(title: const Text('Ingreso — Alerta Desaparecidos PNP')),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                TextField(
                  controller: _phoneController,
                  keyboardType: TextInputType.phone,
                  textInputAction: TextInputAction.done,
                  maxLength: 9,
                  onSubmitted: (_) => _isRegistering ? null : _registerOrLogin(),
                  decoration: const InputDecoration(
                    labelText: 'Número de Celular (Ej: 987654321)',
                    prefixText: '+51 ',
                    border: OutlineInputBorder(),
                  ),
                ),
                if (_errorMessage != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 10.0),
                    child: Text(
                      _errorMessage!,
                      style: const TextStyle(color: Colors.red),
                    ),
                  ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _isRegistering ? null : _registerOrLogin,
                  child: Text(_isRegistering ? 'Verificando...' : 'Continuar'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
EOF

cat << 'EOF' > lib/presentation/screens/otp_screen.dart
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../citizen/screens/citizen_home_screen.dart';
import '../police/screens/police_home_screen.dart';

class OTPScreen extends StatefulWidget {
  final String phoneNumber;
  final String verificationId;
  final ConfirmationResult? webConfirmationResult;

  const OTPScreen({
    super.key,
    required this.phoneNumber,
    required this.verificationId,
    this.webConfirmationResult,
  });

  @override
  State<OTPScreen> createState() => _OTPScreenState();
}

class _OTPScreenState extends State<OTPScreen> {
  final TextEditingController _otpController = TextEditingController();
  String? _errorMessage;
  bool _verifying = false;

  @override
  void dispose() {
    _otpController.dispose();
    super.dispose();
  }

  Future<bool> _isNumberInPoliceCollection(String uid, String phoneNumber) async {
    try {
      final docByUid = await FirebaseFirestore.instance
          .collection('policias')
          .doc(uid)
          .get();
      if (docByUid.exists) return true;

      final snapshot = await FirebaseFirestore.instance
          .collection('policias')
          .where('telefono', isEqualTo: phoneNumber)
          .limit(1)
          .get();
      return snapshot.docs.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  Future<void> _createUserFirestore(String uid, String phoneNumber) async {
    await FirebaseFirestore.instance.collection('ciudadanos').doc(uid).set({
      'telefono': phoneNumber,
      'rol': 'ciudadano',
      'fecha_registro': FieldValue.serverTimestamp(),
      'uid': uid,
    }, SetOptions(merge: true));
  }

  Future<void> _verifyOTPAndNavigate() async {
    final code = _otpController.text.trim();
    if (code.length < 6) {
      setState(() {
        _errorMessage = 'Ingresa los 6 dígitos del código de verificación.';
      });
      return;
    }

    setState(() {
      _errorMessage = null;
      _verifying = true;
    });

    try {
      UserCredential userCredential;
      if (widget.webConfirmationResult != null) {
        userCredential = await widget.webConfirmationResult!.confirm(code);
      } else {
        final credential = PhoneAuthProvider.credential(
          verificationId: widget.verificationId,
          smsCode: code,
        );
        userCredential =
            await FirebaseAuth.instance.signInWithCredential(credential);
      }

      final User? user = userCredential.user;
      if (user == null) {
        if (!mounted) return;
        setState(() {
          _errorMessage = 'No se pudo obtener la sesión del usuario.';
          _verifying = false;
        });
        return;
      }

      final prefs = await SharedPreferences.getInstance();
      final isPolice =
          await _isNumberInPoliceCollection(user.uid, widget.phoneNumber);

      if (isPolice) {
        await prefs.setString('cached_role_${user.uid}', 'police');
        if (!mounted) return;
        // Limpia toda la pila de navegación en iOS para que no regrese a RegistrationScreen
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const PoliceHomeScreen()),
          (route) => false,
        );
      } else {
        try {
          await _createUserFirestore(user.uid, widget.phoneNumber);
        } catch (e) {
          debugPrint('[OTP] Aviso guardando perfil ciudadano: $e');
        }
        await prefs.setString('cached_role_${user.uid}', 'citizen');
        if (!mounted) return;
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const CitizenHomeScreen()),
          (route) => false,
        );
      }
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;
      setState(() {
        _errorMessage = 'Código OTP inválido o expirado: ${e.message ?? e.code}';
        _verifying = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _errorMessage = 'Ocurrió un error al verificar el código: $e';
        _verifying = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: AppBar(title: const Text('Verificar Código SMS')),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Text('Se envió un código de 6 dígitos a ${widget.phoneNumber}'),
                const SizedBox(height: 12),
                TextField(
                  controller: _otpController,
                  keyboardType: TextInputType.number,
                  // Habilita autocompletado nativo de SMS en iPhone (iOS One-Time Code)
                  autofillHints: const [AutofillHints.oneTimeCode],
                  maxLength: 6,
                  onSubmitted: (_) => _verifying ? null : _verifyOTPAndNavigate(),
                  decoration: const InputDecoration(
                    labelText: 'Código OTP',
                    border: OutlineInputBorder(),
                  ),
                ),
                if (_errorMessage != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 10.0),
                    child: Text(
                      _errorMessage!,
                      style: const TextStyle(color: Colors.red),
                    ),
                  ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _verifying ? null : _verifyOTPAndNavigate,
                  child: Text(_verifying ? 'Verificando...' : 'Verificar e Ingresar'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
EOF

echo "[5/10] Actualizando lib/helpers/database_helpers.dart (Soporte Ubigeo en memoria para Safari iPhone / Web y Batch en móvil)..."
cat << 'EOF' > lib/helpers/database_helpers.dart
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:path/path.dart';
import 'package:sqflite/sqflite.dart';

/// Helper multiplataforma de Ubigeo Perú.
/// Soluciona el fallo en Flutter Web y Safari iPhone (donde sqflite nativo no existe)
/// parseando en memoria el archivo 'assets/ubigeo_peru.sql', y en Android/iOS nativo
/// ejecuta un Batch transaccional 20x más rápido.
class DatabaseHelper {
  static const String sqlFileName = 'ubigeo_peru.sql';
  static const String dbName = 'ubigeo_peru.sqlite';
  static Database? _database;

  static List<Map<String, dynamic>>? _webDepartmentsCache;
  static List<Map<String, dynamic>>? _webProvincesCache;
  static List<Map<String, dynamic>>? _webDistrictsCache;

  Future<Database> get database async {
    if (_database != null) return _database!;
    _database = await _initDatabase();
    return _database!;
  }

  Future<void> _ensureWebMemoryCache() async {
    if (_webDepartmentsCache != null) return;
    _webDepartmentsCache = [];
    _webProvincesCache = [];
    _webDistrictsCache = [];

    try {
      final String sqlScript = await rootBundle.loadString('assets/$sqlFileName');
      final RegExp tupleRegex = RegExp(r"\('([^']*)',\s*'([^']*)'(?:,\s*'([^']*)')?(?:,\s*'([^']*)')?\)");

      for (final rawLine in sqlScript.split(';')) {
        final line = rawLine.trim();
        if (line.contains('ubigeo_peru_departments')) {
          for (final m in tupleRegex.allMatches(line)) {
            _webDepartmentsCache!.add({
              'id': m.group(1) ?? '',
              'name': m.group(2) ?? '',
            });
          }
        } else if (line.contains('ubigeo_peru_provinces')) {
          for (final m in tupleRegex.allMatches(line)) {
            _webProvincesCache!.add({
              'id': m.group(1) ?? '',
              'name': m.group(2) ?? '',
              'department_id': m.group(3) ?? '',
            });
          }
        } else if (line.contains('ubigeo_peru_districts')) {
          for (final m in tupleRegex.allMatches(line)) {
            _webDistrictsCache!.add({
              'id': m.group(1) ?? '',
              'name': m.group(2) ?? '',
              'province_id': m.group(3) ?? '',
              'department_id': m.group(4) ?? '',
            });
          }
        }
      }
    } catch (e) {
      debugPrint('[UbigeoMemory] Error cargando ubigeo en memoria: $e');
    }
  }

  Future<Database> _initDatabase() async {
    final String dbPath = await getDatabasesPath();
    final String path = join(dbPath, dbName);

    return await openDatabase(
      path,
      version: 1,
      onCreate: (db, version) async {
        final String sqlScript =
            await rootBundle.loadString('assets/$sqlFileName');
        final List<String> sqlCommands = sqlScript.split(';');
        final Batch batch = db.batch();
        for (final command in sqlCommands) {
          if (command.trim().isNotEmpty) {
            batch.execute(command.trim());
          }
        }
        await batch.commit(noResult: true);
      },
    );
  }

  Future<List<Map<String, dynamic>>> getDepartamentos() async {
    if (kIsWeb) {
      await _ensureWebMemoryCache();
      return _webDepartmentsCache ?? [];
    }
    try {
      final db = await database;
      return await db.query('ubigeo_peru_departments');
    } catch (_) {
      await _ensureWebMemoryCache();
      return _webDepartmentsCache ?? [];
    }
  }

  Future<List<Map<String, dynamic>>> getProvincias(String departmentId) async {
    if (kIsWeb) {
      await _ensureWebMemoryCache();
      return (_webProvincesCache ?? [])
          .where((p) => p['department_id'] == departmentId)
          .toList();
    }
    try {
      final db = await database;
      return await db.query(
        'ubigeo_peru_provinces',
        where: 'department_id = ?',
        whereArgs: [departmentId],
      );
    } catch (_) {
      await _ensureWebMemoryCache();
      return (_webProvincesCache ?? [])
          .where((p) => p['department_id'] == departmentId)
          .toList();
    }
  }

  Future<List<Map<String, dynamic>>> getDistritos(String provinceId) async {
    if (kIsWeb) {
      await _ensureWebMemoryCache();
      return (_webDistrictsCache ?? [])
          .where((d) => d['province_id'] == provinceId)
          .toList();
    }
    try {
      final db = await database;
      return await db.query(
        'ubigeo_peru_districts',
        where: 'province_id = ?',
        whereArgs: [provinceId],
      );
    } catch (_) {
      await _ensureWebMemoryCache();
      return (_webDistrictsCache ?? [])
          .where((d) => d['province_id'] == provinceId)
          .toList();
    }
  }
}
EOF

echo "[6/10] Actualizando web/index.html (Viewport 100dvh para Safari iPhone) y ios/Runner/Info.plist (Permisos y URL Schemes iOS)..."
cat << 'EOF' > web/index.html
<!DOCTYPE html>
<html lang="es-PE">
<head>
  <base href="$FLUTTER_BASE_HREF">

  <meta charset="UTF-8">
  <meta content="IE=Edge" http-equiv="X-UA-Compatible">
  <!-- Viewport optimizado para iPhone (evita auto-zoom en inputs y respeta el notch / barra inferior con viewport-fit=cover) -->
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no, viewport-fit=cover">
  <meta name="description" content="Alerta Desaparecidos PNP (Chinkasqakuna Alerta) — Red Nacional y Comunitaria de Búsqueda Temprana, Radar GPS de Comisarías y Protección Familiar.">
  <meta name="theme-color" content="#0D47A1">

  <!-- Etiquetas específicas de compatibilidad PWA en iPhone / iOS Safari -->
  <meta name="mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-capable" content="yes">
  <meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
  <meta name="apple-mobile-web-app-title" content="Alerta PNP">
  <link rel="apple-touch-icon" href="icons/Icon-192.png">

  <link rel="icon" type="image/png" href="favicon.png"/>
  <title>Alerta Desaparecidos PNP</title>
  <link rel="manifest" href="manifest.json">

  <style>
    html, body {
      margin: 0;
      padding: 0;
      width: 100%;
      height: 100%;
      height: 100dvh;
      background-color: #0A192F;
      overflow: hidden;
      -webkit-tap-highlight-color: transparent;
      -webkit-touch-callout: none;
    }
  </style>
</head>
<body>
  <script src="flutter_bootstrap.js" async></script>
</body>
</html>
EOF

cat << 'EOF' > ios/Runner/Info.plist
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>CFBundleDevelopmentRegion</key>
	<string>$(DEVELOPMENT_LANGUAGE)</string>
	<key>CFBundleDisplayName</key>
	<string>Alerta Desaparecidos PNP</string>
	<key>CFBundleExecutable</key>
	<string>$(EXECUTABLE_NAME)</string>
	<key>CFBundleIdentifier</key>
	<string>$(PRODUCT_BUNDLE_IDENTIFIER)</string>
	<key>CFBundleInfoDictionaryVersion</key>
	<string>6.0</string>
	<key>CFBundleName</key>
	<string>alerta_desaparecidos</string>
	<key>CFBundlePackageType</key>
	<string>APPL</string>
	<key>CFBundleShortVersionString</key>
	<string>$(FLUTTER_BUILD_NAME)</string>
	<key>CFBundleSignature</key>
	<string>????</string>
	<key>CFBundleVersion</key>
	<string>$(FLUTTER_BUILD_NUMBER)</string>
	<key>LSRequiresIPhoneOS</key>
	<true/>
	<key>UILaunchStoryboardName</key>
	<string>LaunchScreen</string>
	<key>UIMainStoryboardFile</key>
	<string>Main</string>
	<key>UISupportedInterfaceOrientations</key>
	<array>
		<string>UIInterfaceOrientationPortrait</string>
		<string>UIInterfaceOrientationLandscapeLeft</string>
		<string>UIInterfaceOrientationLandscapeRight</string>
	</array>
	<key>UISupportedInterfaceOrientations~ipad</key>
	<array>
		<string>UIInterfaceOrientationPortrait</string>
		<string>UIInterfaceOrientationPortraitUpsideDown</string>
		<string>UIInterfaceOrientationLandscapeLeft</string>
		<string>UIInterfaceOrientationLandscapeRight</string>
	</array>
	<key>CADisableMinimumFrameDurationOnPhone</key>
	<true/>
	<key>UIApplicationSupportsIndirectInputEvents</key>
	<true/>

	<!-- ===================================================================== -->
	<!-- PERMISOS OBLIGATORIOS EN iPHONE (Evitan cierre inesperado SIGABRT)   -->
	<!-- ===================================================================== -->
	<key>NSLocationWhenInUseUsageDescription</key>
	<string>Necesitamos tu ubicación GPS para mostrarte la comisaría PNP más cercana y registrar el lugar exacto de avistamientos.</string>
	<key>NSLocationAlwaysAndWhenInUseUsageDescription</key>
	<string>Necesitamos tu ubicación GPS para alertas de búsqueda temprana en tu provincia y ruta a comisarías cercanas.</string>
	<key>NSCameraUsageDescription</key>
	<string>Necesitamos acceso a la cámara para tomar la fotografía reciente de la ficha de búsqueda o evidencia de avistamiento.</string>
	<key>NSPhotoLibraryUsageDescription</key>
	<string>Necesitamos acceso a tu galería para adjuntar la fotografía de la persona desaparecida o guardar el Carnet SOS.</string>
	<key>NSPhotoLibraryAddUsageDescription</key>
	<string>Permite guardar el Afiche de Búsqueda y el Carnet Escudo SOS en tu dispositivo.</string>

	<!-- Permite llamadas directas a Línea 114, 105, 100 y WhatsApp en iPhone -->
	<key>LSApplicationQueriesSchemes</key>
	<array>
		<string>tel</string>
		<string>whatsapp</string>
		<string>https</string>
		<string>comgooglemaps</string>
		<string>iosamap</string>
	</array>

	<!-- Esquema de retorno para Firebase Auth / reCAPTCHA en iPhone -->
	<key>CFBundleURLTypes</key>
	<array>
		<dict>
			<key>CFBundleTypeRole</key>
			<string>Editor</string>
			<key>CFBundleURLName</key>
			<string>com.shamirdhc.alertaDesaparecidos</string>
			<key>CFBundleURLSchemes</key>
			<array>
				<string>com.shamirdhc.alertaDesaparecidos</string>
				<string>app-1-75698715605-ios-99a336d9f0e533db151b5c</string>
			</array>
		</dict>
	</array>
</dict>
</plist>
EOF

echo "[7/10] Corrigiendo lib/injection.dart (Línea 12 import corrupto y registro de ManageMissingViewModel)..."
cat << 'EOF' > lib/injection.dart
import 'package:get_it/get_it.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_storage/firebase_storage.dart';

// Data Layer
import 'package:alerta_desaparecidos/data/data_sources/desaparecido_remote_data_source.dart';
import 'package:alerta_desaparecidos/data/repositories/desaparecido_repository_impl.dart';

// Domain Layer
import 'package:alerta_desaparecidos/domain/repositories/desaparecido_repository.dart';
import 'package:alerta_desaparecidos/domain/use_cases/obtener_desaparecidos_use_case.dart';
import 'package:alerta_desaparecidos/domain/use_cases/reportar_desaparicion_use_case.dart';
import 'package:alerta_desaparecidos/domain/use_cases/marcar_como_encontrado_use_case.dart';

// Presentation Layer
import 'package:alerta_desaparecidos/presentation/citizen/view_models/view_missing_view_model.dart';
import 'package:alerta_desaparecidos/presentation/police/view_models/add_missing_view_model.dart';
import 'package:alerta_desaparecidos/presentation/police/view_models/manage_missing_view_model.dart';

final locator = GetIt.instance;

void init() {
  if (locator.isRegistered<FirebaseFirestore>()) return;

  locator.registerLazySingleton(() => FirebaseFirestore.instance);
  locator.registerLazySingleton(() => FirebaseStorage.instance);

  locator.registerLazySingleton<DesaparecidoRemoteDataSource>(
    () => DesaparecidoRemoteDataSource(
      locator<FirebaseFirestore>(),
      locator<FirebaseStorage>(),
    ),
  );

  locator.registerLazySingleton<DesaparecidoRepository>(
    () => DesaparecidoRepositoryImpl(
      locator<DesaparecidoRemoteDataSource>(),
    ),
  );

  locator.registerLazySingleton(
    () => ObtenerDesaparecidosUseCase(locator<DesaparecidoRepository>()),
  );
  locator.registerLazySingleton(
    () => ReportarDesaparicionUseCase(locator<DesaparecidoRepository>()),
  );
  locator.registerLazySingleton(
    () => MarcarComoEncontradoUseCase(locator<DesaparecidoRepository>()),
  );

  locator.registerFactory(
    () => ViewMissingViewModel(locator<ObtenerDesaparecidosUseCase>()),
  );
  locator.registerFactory(
    () => AddMissingViewModel(locator<ReportarDesaparicionUseCase>()),
  );
  locator.registerFactory(
    () => ManageMissingViewModel(
      locator<ObtenerDesaparecidosUseCase>(),
      locator<MarcarComoEncontradoUseCase>(),
    ),
  );
}
EOF

echo "[8/10] Actualizando lib/domain/entities/desaparecido.dart (Añade nombre_lower y parseo seguro de fechas)..."
cat << 'EOF' > lib/domain/entities/desaparecido.dart
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';

class Desaparecido extends Equatable {
  final String? id;
  final String nombres;
  final String apellidos;
  final String? sexo;
  final String? dni;
  final String? telefonoContacto;
  final DateTime? fechaNacimiento;
  final DateTime? fechaDesaparicion;
  final String? departamento;
  final String? provincia;
  final String? distrito;
  final String? detallesAdicionales;
  final String? _estado;
  final DateTime? fechaEncontrado;
  final String? fotoUrl;
  final String? imagenFichaUrl;
  final DateTime? fechaCreacion;
  final DateTime? fechaActualizacion;

  const Desaparecido({
    this.id,
    required this.nombres,
    required this.apellidos,
    this.sexo,
    this.dni,
    this.telefonoContacto,
    this.fechaNacimiento,
    this.fechaDesaparicion,
    this.departamento,
    this.provincia,
    this.distrito,
    this.detallesAdicionales,
    String? estado,
    this.fechaEncontrado,
    this.fotoUrl,
    this.imagenFichaUrl,
    this.fechaCreacion,
    this.fechaActualizacion,
  }) : _estado = estado ?? 'activo';

  String? get estado => _estado;

  Desaparecido copyWith({
    String? id,
    String? nombres,
    String? apellidos,
    String? sexo,
    String? dni,
    String? telefonoContacto,
    DateTime? fechaNacimiento,
    DateTime? fechaDesaparicion,
    String? departamento,
    String? provincia,
    String? distrito,
    String? detallesAdicionales,
    String? estado,
    DateTime? fechaEncontrado,
    String? fotoUrl,
    String? imagenFichaUrl,
    DateTime? fechaCreacion,
    DateTime? fechaActualizacion,
  }) {
    return Desaparecido(
      id: id ?? this.id,
      nombres: nombres ?? this.nombres,
      apellidos: apellidos ?? this.apellidos,
      sexo: sexo ?? this.sexo,
      dni: dni ?? this.dni,
      telefonoContacto: telefonoContacto ?? this.telefonoContacto,
      fechaNacimiento: fechaNacimiento ?? this.fechaNacimiento,
      fechaDesaparicion: fechaDesaparicion ?? this.fechaDesaparicion,
      departamento: departamento ?? this.departamento,
      provincia: provincia ?? this.provincia,
      distrito: distrito ?? this.distrito,
      detallesAdicionales: detallesAdicionales ?? this.detallesAdicionales,
      estado: estado ?? _estado,
      fechaEncontrado: fechaEncontrado ?? this.fechaEncontrado,
      fotoUrl: fotoUrl ?? this.fotoUrl,
      imagenFichaUrl: imagenFichaUrl ?? this.imagenFichaUrl,
      fechaCreacion: fechaCreacion ?? this.fechaCreacion,
      fechaActualizacion: fechaActualizacion ?? this.fechaActualizacion,
    );
  }

  static DateTime? _parseDate(dynamic value) {
    if (value == null) return null;
    if (value is Timestamp) return value.toDate();
    if (value is DateTime) return value;
    if (value is String) return DateTime.tryParse(value);
    return null;
  }

  Map<String, dynamic> toMap() {
    final fullLower = '${nombres.trim()} ${apellidos.trim()}'.toLowerCase();
    final effectiveFechaDesaparicion =
        fechaDesaparicion ?? fechaCreacion ?? DateTime.now();
    return {
      'nombres': nombres.trim(),
      'apellidos': apellidos.trim(),
      'nombre_lower': fullLower,
      'sexo': sexo,
      'dni': dni?.trim(),
      'telefono_contacto': telefonoContacto?.trim(),
      'fecha_nacimiento':
          fechaNacimiento != null ? Timestamp.fromDate(fechaNacimiento!) : null,
      'fecha_desaparicion': Timestamp.fromDate(effectiveFechaDesaparicion),
      'departamento': departamento,
      'provincia': provincia,
      'distrito': distrito,
      'detalles_adicionales': detallesAdicionales?.trim(),
      'estado': _estado ?? 'activo',
      'fecha_encontrado':
          fechaEncontrado != null ? Timestamp.fromDate(fechaEncontrado!) : null,
      'foto_url': fotoUrl,
      'imagen_ficha_url': imagenFichaUrl,
      'fecha_creacion': Timestamp.fromDate(fechaCreacion ?? DateTime.now()),
      'fecha_actualizacion':
          Timestamp.fromDate(fechaActualizacion ?? DateTime.now()),
    };
  }

  factory Desaparecido.fromMap(Map<String, dynamic> map, String? id) {
    return Desaparecido(
      id: id,
      nombres: (map['nombres'] ?? '').toString(),
      apellidos: (map['apellidos'] ?? '').toString(),
      sexo: map['sexo']?.toString(),
      dni: map['dni']?.toString(),
      telefonoContacto: map['telefono_contacto']?.toString(),
      fechaNacimiento: _parseDate(map['fecha_nacimiento']),
      fechaDesaparicion: _parseDate(map['fecha_desaparicion']) ??
          _parseDate(map['fecha_creacion']),
      departamento: map['departamento']?.toString(),
      provincia: map['provincia']?.toString(),
      distrito: map['distrito']?.toString(),
      detallesAdicionales: map['detalles_adicionales']?.toString(),
      estado: (map['estado'] ?? 'activo').toString(),
      fechaEncontrado: _parseDate(map['fecha_encontrado']),
      fotoUrl: (map['foto_url'] ?? map['fotoUrl'])?.toString(),
      imagenFichaUrl:
          (map['imagen_ficha_url'] ?? map['imagenFichaUrl'])?.toString(),
      fechaCreacion: _parseDate(map['fecha_creacion']),
      fechaActualizacion: _parseDate(map['fecha_actualizacion']),
    );
  }

  @override
  List<Object?> get props => [
        id,
        nombres,
        apellidos,
        sexo,
        dni,
        telefonoContacto,
        fechaNacimiento,
        fechaDesaparicion,
        departamento,
        provincia,
        distrito,
        detallesAdicionales,
        _estado,
        fechaEncontrado,
        fotoUrl,
        imagenFichaUrl,
        fechaCreacion,
        fechaActualizacion,
      ];
}
EOF

echo "[8/10] Corrigiendo lib/data/data_sources/desaparecido_remote_data_source.dart (Elimina N+1, corrige ruta null y comprime a WebP)..."
cat << 'EOF' > lib/data/data_sources/desaparecido_remote_data_source.dart
import 'dart:async';
import 'dart:typed_data';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dartz/dartz.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import '../../common/failure.dart';
import '../../domain/entities/desaparecido.dart';
import '../../domain/enums.dart';

class DesaparecidoRemoteDataSource {
  final CollectionReference<Map<String, dynamic>> _desaparecidosCollection;
  final FirebaseStorage _storage;

  DesaparecidoRemoteDataSource(FirebaseFirestore firestore, this._storage)
      : _desaparecidosCollection = firestore.collection('desaparecidos');

  Future<Either<Failure, List<Desaparecido>>> getDesaparecidos({
    MissingFilter filter = MissingFilter.active,
    int? limit = 20,
    Desaparecido? lastDesaparecido,
    String? searchQuery,
    String? departamento,
  }) async {
    final cleanedQuery = searchQuery?.trim();
    if (cleanedQuery != null && cleanedQuery.isNotEmpty) {
      return _getDesaparecidosConBusquedaOr(
        filter: filter,
        limit: limit,
        searchQuery: cleanedQuery,
        departamento: departamento,
      );
    } else {
      return _getDesaparecidosSimple(
        filter: filter,
        limit: limit,
        lastDesaparecido: lastDesaparecido,
        departamento: departamento,
      );
    }
  }

  Future<Either<Failure, List<Desaparecido>>> _getDesaparecidosConBusquedaOr({
    required MissingFilter filter,
    int? limit,
    required String searchQuery,
    String? departamento,
  }) async {
    try {
      final queryLower = searchQuery.toLowerCase();

      Query<Map<String, dynamic>> queryNombre = _buildBaseQuery(filter, departamento)
          .where('nombre_lower', isGreaterThanOrEqualTo: queryLower)
          .where('nombre_lower', isLessThanOrEqualTo: '$queryLower\uf8ff');
      if (limit != null) queryNombre = queryNombre.limit(limit);

      Query<Map<String, dynamic>> queryDni = _buildBaseQuery(filter, departamento)
          .where('dni', isGreaterThanOrEqualTo: searchQuery)
          .where('dni', isLessThanOrEqualTo: '$searchQuery\uf8ff');
      if (limit != null) queryDni = queryDni.limit(limit);

      final results = await Future.wait([queryNombre.get(), queryDni.get()]);
      final Map<String, Desaparecido> desaparecidosMap = {};

      for (var doc in results[0].docs) {
        final item = await _mapDocToDesaparecido(doc);
        if (item.id != null) desaparecidosMap[item.id!] = item;
      }
      for (var doc in results[1].docs) {
        if (!desaparecidosMap.containsKey(doc.id)) {
          final item = await _mapDocToDesaparecido(doc);
          if (item.id != null) desaparecidosMap[item.id!] = item;
        }
      }

      List<Desaparecido> list = desaparecidosMap.values.toList();
      final epoch = DateTime.fromMillisecondsSinceEpoch(0);
      list.sort((a, b) {
        final dateA = a.fechaDesaparicion ?? a.fechaCreacion ?? epoch;
        final dateB = b.fechaDesaparicion ?? b.fechaCreacion ?? epoch;
        return dateB.compareTo(dateA);
      });

      if (limit != null && list.length > limit) {
        list = list.sublist(0, limit);
      }
      return Right(list);
    } on FirebaseException catch (e) {
      return Left(DatabaseFailure('Error de Firestore (${e.code}): ${e.message}'));
    } catch (e) {
      return Left(DatabaseFailure('Error al buscar casos: $e'));
    }
  }

  Future<Either<Failure, List<Desaparecido>>> _getDesaparecidosSimple({
    required MissingFilter filter,
    int? limit,
    Desaparecido? lastDesaparecido,
    String? departamento,
  }) async {
    try {
      Query<Map<String, dynamic>> query = _buildBaseQuery(filter, departamento)
          .orderBy('fecha_desaparicion', descending: true);

      if (lastDesaparecido?.id != null) {
        final lastDocSnapshot =
            await _desaparecidosCollection.doc(lastDesaparecido!.id).get();
        if (lastDocSnapshot.exists) {
          query = query.startAfterDocument(lastDocSnapshot);
        }
      }

      if (limit != null) {
        query = query.limit(limit);
      }

      final querySnapshot = await query.get();
      final desaparecidosList = await Future.wait(
        querySnapshot.docs.map(_mapDocToDesaparecido),
      );

      return Right(desaparecidosList);
    } on FirebaseException catch (e) {
      return Left(DatabaseFailure('Error de Firestore (${e.code}): ${e.message}'));
    } catch (e) {
      return Left(DatabaseFailure('Error inesperado al obtener casos: $e'));
    }
  }

  Query<Map<String, dynamic>> _buildBaseQuery(
    MissingFilter filter,
    String? departamento,
  ) {
    Query<Map<String, dynamic>> query = _desaparecidosCollection;

    switch (filter) {
      case MissingFilter.active:
        query = query.where('estado', isEqualTo: 'activo');
        break;
      case MissingFilter.found:
        query = query.where('estado', isEqualTo: 'encontrado');
        break;
      case MissingFilter.all:
        break;
    }

    if (departamento != null && departamento.trim().isNotEmpty) {
      query = query.where('departamento', isEqualTo: departamento.trim());
    }

    return query;
  }

  Future<Desaparecido> _mapDocToDesaparecido(
    DocumentSnapshot<Map<String, dynamic>> doc,
  ) async {
    final data = doc.data() ?? <String, dynamic>{};
    final base = Desaparecido.fromMap(data, doc.id);

    if (base.departamento != null && base.departamento!.isNotEmpty) {
      return base;
    }

    try {
      final ubicacionDoc =
          await doc.reference.collection('ubicacion').doc('detalles').get();
      if (ubicacionDoc.exists && ubicacionDoc.data() != null) {
        final u = ubicacionDoc.data()!;
        return base.copyWith(
          departamento: u['departamento']?.toString() ?? base.departamento,
          provincia: u['provincia']?.toString() ?? base.provincia,
          distrito: u['distrito']?.toString() ?? base.distrito,
        );
      }
    } catch (_) {}

    return base;
  }

  Future<Either<Failure, String>> uploadImage(
    String path,
    Uint8List imageBytes,
  ) async {
    Uint8List payload = imageBytes;
    try {
      payload = await FlutterImageCompress.compressWithList(
        imageBytes,
        minWidth: 1080,
        minHeight: 1080,
        quality: 78,
        format: CompressFormat.webp,
      );
    } catch (_) {
      payload = imageBytes;
    }

    if (payload.lengthInBytes > 5 * 1024 * 1024) {
      return Left(DatabaseFailure('La fotografía supera el límite máximo de 5 MB.'));
    }

    int attempt = 0;
    while (true) {
      try {
        attempt++;
        final Reference storageRef = _storage.ref().child(path);
        final metadata = SettableMetadata(
          contentType: 'image/webp',
          cacheControl: 'public, max-age=31536000, immutable',
        );
        final TaskSnapshot snapshot = await storageRef
            .putData(payload, metadata)
            .timeout(const Duration(seconds: 25));
        final String downloadUrl = await snapshot.ref.getDownloadURL();
        return Right(downloadUrl);
      } on FirebaseException catch (e) {
        if (attempt >= 3) {
          return Left(DatabaseFailure(e.message ?? 'Error al subir la fotografía.'));
        }
        await Future.delayed(Duration(seconds: 1 << (attempt - 1)));
      } catch (e) {
        if (attempt >= 3) {
          return Left(DatabaseFailure('Fallo de red al subir imagen: $e'));
        }
        await Future.delayed(Duration(seconds: 1 << (attempt - 1)));
      }
    }
  }

  Future<Either<Failure, void>> reportarDesaparecido(
    Desaparecido desaparecido, {
    Uint8List? fotoBytes,
    Uint8List? fichaBytes,
  }) async {
    try {
      final DocumentReference<Map<String, dynamic>> docRef =
          (desaparecido.id != null && desaparecido.id!.isNotEmpty)
              ? _desaparecidosCollection.doc(desaparecido.id)
              : _desaparecidosCollection.doc();

      String? fotoUrl = desaparecido.fotoUrl;
      String? fichaUrl = desaparecido.imagenFichaUrl;

      if (fotoBytes != null) {
        final fotoResult = await uploadImage(
          'desaparecidos/${docRef.id}/foto.webp',
          fotoBytes,
        );
        fotoResult.fold((l) => throw Exception(l.message), (r) => fotoUrl = r);
      }

      if (fichaBytes != null) {
        final fichaResult = await uploadImage(
          'desaparecidos/${docRef.id}/ficha.webp',
          fichaBytes,
        );
        fichaResult.fold((l) => throw Exception(l.message), (r) => fichaUrl = r);
      }

      final recordToSave = desaparecido.copyWith(
        id: docRef.id,
        fotoUrl: fotoUrl,
        imagenFichaUrl: fichaUrl,
        fechaCreacion: desaparecido.fechaCreacion ?? DateTime.now(),
        fechaActualizacion: DateTime.now(),
      );

      await docRef.set(recordToSave.toMap());
      return const Right(null);
    } on FirebaseException catch (e) {
      return Left(DatabaseFailure(e.message ?? 'Error al guardar el reporte en Firestore.'));
    } catch (e) {
      return Left(DatabaseFailure(e.toString()));
    }
  }

  Future<Either<Failure, void>> marcarComoEncontrado(
    String desaparecidoId,
  ) async {
    try {
      await _desaparecidosCollection.doc(desaparecidoId).update({
        'estado': 'encontrado',
        'fecha_encontrado': FieldValue.serverTimestamp(),
        'fecha_actualizacion': FieldValue.serverTimestamp(),
      });
      return const Right(null);
    } on FirebaseException catch (e) {
      return Left(DatabaseFailure(e.message ?? 'Error al marcar como encontrado.'));
    } catch (e) {
      return Left(DatabaseFailure(e.toString()));
    }
  }
}
EOF

echo "[9/10] Generando firestore.rules y storage.rules..."
cat << 'EOF' > firestore.rules
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    function isAuthenticated() {
      return request.auth != null;
    }

    function isPoliceOfficer() {
      return isAuthenticated() && (
        request.auth.token.role == 'police' ||
        request.auth.token.role == 'superadmin' ||
        exists(/databases/$(database)/documents/policias/$(request.auth.uid))
      );
    }

    function isSuperAdmin() {
      return isAuthenticated() && request.auth.token.role == 'superadmin';
    }

    function isSafeString(val, minLen, maxLen) {
      return val is string &&
             val.size() >= minLen &&
             val.size() <= maxLen &&
             !val.matches('.*(<script|javascript:|onerror=|onload=|<iframe).*');
    }

    match /desaparecidos/{casoId} {
      allow read: if true;

      allow create: if isPoliceOfficer() &&
        isSafeString(request.resource.data.nombres, 2, 80) &&
        isSafeString(request.resource.data.apellidos, 2, 80) &&
        request.resource.data.estado in ['activo', 'encontrado'];

      allow update: if isPoliceOfficer() &&
        request.resource.data.estado in ['activo', 'encontrado'];

      allow delete: if isSuperAdmin();

      match /ubicacion/{docId} {
        allow read: if true;
        allow write: if isPoliceOfficer();
      }

      match /pistas/{pistaId} {
        allow read: if isPoliceOfficer() || resource.data.estadoModeracion == 'APROBADO';
        allow create: if isSafeString(request.resource.data.detalles, 5, 600);
        allow update, delete: if isPoliceOfficer();
      }
    }

    match /policias/{uid} {
      allow get: if isAuthenticated() && (request.auth.uid == uid || isSuperAdmin());
      allow list: if isSuperAdmin();
      allow create, update, delete: if isSuperAdmin();
    }

    match /ciudadanos/{uid} {
      allow get: if isAuthenticated() && (request.auth.uid == uid || isPoliceOfficer());
      allow list: if isPoliceOfficer();
      allow create: if isAuthenticated() &&
        request.auth.uid == uid &&
        request.resource.data.rol == 'ciudadano' &&
        request.resource.data.uid == uid;
      allow update: if isAuthenticated() &&
        request.auth.uid == uid &&
        request.resource.data.rol == 'ciudadano';
      allow delete: if isSuperAdmin();
    }

    match /vetados/{phoneId} {
      allow get: if true;
      allow list: if isPoliceOfficer();
      allow write: if isSuperAdmin();
    }

    match /{document=**} {
      allow read, write: if false;
    }
  }
}
EOF

cat << 'EOF' > storage.rules
rules_version = '2';
service firebase.storage {
  match /b/{bucket}/o {

    function isPoliceOfficer() {
      return request.auth != null && (
        request.auth.token.role == 'police' ||
        request.auth.token.role == 'superadmin' ||
        firestore.exists(/databases/(default)/documents/policias/$(request.auth.uid))
      );
    }

    function isValidImage(maxMegabytes) {
      return request.resource != null &&
             request.resource.size < maxMegabytes * 1024 * 1024 &&
             request.resource.contentType.matches('image/(jpeg|png|webp)');
    }

    match /desaparecidos/{subPath=**} {
      allow read: if true;
      allow create, update: if isPoliceOfficer() && isValidImage(5);
      allow delete: if request.auth != null && request.auth.token.role == 'superadmin';
    }

    match /pistas_ciudadanas/{casoId}/{pistaFile} {
      allow read: if isPoliceOfficer();
      allow create: if isValidImage(3) && pistaFile.size() <= 80;
      allow update, delete: if isPoliceOfficer();
    }

    match /{allPaths=**} {
      allow read, write: if false;
    }
  }
}
EOF

echo "[9/10] Actualizando firebase.json y firestore.indexes.json..."
cat << 'EOF' > firebase.json
{
  "flutter": {
    "platforms": {
      "android": {
        "default": {
          "projectId": "alerta-desaparecidos-pnp",
          "appId": "1:75698715605:android:0457d3e14a710c5c151b5c",
          "fileOutput": "android/app/google-services.json"
        }
      },
      "dart": {
        "lib/firebase_options.dart": {
          "projectId": "alerta-desaparecidos-pnp",
          "configurations": {
            "android": "1:75698715605:android:0457d3e14a710c5c151b5c",
            "ios": "1:75698715605:ios:99a336d9f0e533db151b5c",
            "web": "1:75698715605:web:a77a01a49471b69d151b5c",
            "windows": "1:75698715605:web:a77a01a49471b69d151b5c"
          }
        }
      }
    }
  },
  "firestore": {
    "rules": "firestore.rules",
    "indexes": "firestore.indexes.json"
  },
  "storage": {
    "rules": "storage.rules"
  },
  "hosting": {
    "public": "build/web",
    "ignore": [
      "firebase.json",
      "**/.*",
      "**/node_modules/**"
    ],
    "rewrites": [
      {
        "source": "**",
        "destination": "/index.html"
      }
    ],
    "headers": [
      {
        "source": "**",
        "headers": [
          {
            "key": "Strict-Transport-Security",
            "value": "max-age=63072000; includeSubDomains; preload"
          },
          {
            "key": "X-Content-Type-Options",
            "value": "nosniff"
          },
          {
            "key": "X-Frame-Options",
            "value": "DENY"
          },
          {
            "key": "Referrer-Policy",
            "value": "strict-origin-when-cross-origin"
          },
          {
            "key": "Permissions-Policy",
            "value": "geolocation=(self), camera=(self), microphone=(), payment=(), usb=()"
          },
          {
            "key": "Content-Security-Policy",
            "value": "default-src 'self'; script-src 'self' 'unsafe-inline' 'unsafe-eval' https://www.gstatic.com https://apis.google.com https://www.google.com; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; font-src 'self' https://fonts.gstatic.com data:; img-src 'self' data: blob: https://*.googleapis.com https://*.ggpht.com https://*.tile.openstreetmap.org https://firebasestorage.googleapis.com; connect-src 'self' https://*.googleapis.com https://*.firebaseio.com wss://*.firebaseio.com https://*.tile.openstreetmap.org https://router.project-osrm.org https://identitytoolkit.googleapis.com https://securetoken.googleapis.com; frame-src 'self' https://www.google.com https://*.firebaseapp.com; object-src 'none'; base-uri 'self';"
          }
        ]
      }
    ]
  }
}
EOF

cat << 'EOF' > firestore.indexes.json
{
  "indexes": [
    {
      "collectionGroup": "desaparecidos",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "estado", "order": "ASCENDING" },
        { "fieldPath": "fecha_desaparicion", "order": "DESCENDING" }
      ]
    },
    {
      "collectionGroup": "desaparecidos",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "estado", "order": "ASCENDING" },
        { "fieldPath": "departamento", "order": "ASCENDING" },
        { "fieldPath": "fecha_desaparicion", "order": "DESCENDING" }
      ]
    },
    {
      "collectionGroup": "desaparecidos",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "estado", "order": "ASCENDING" },
        { "fieldPath": "nombre_lower", "order": "ASCENDING" }
      ]
    },
    {
      "collectionGroup": "desaparecidos",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "estado", "order": "ASCENDING" },
        { "fieldPath": "departamento", "order": "ASCENDING" },
        { "fieldPath": "nombre_lower", "order": "ASCENDING" }
      ]
    },
    {
      "collectionGroup": "desaparecidos",
      "queryScope": "COLLECTION",
      "fields": [
        { "fieldPath": "estado", "order": "ASCENDING" },
        { "fieldPath": "dni", "order": "ASCENDING" }
      ]
    }
  ],
  "fieldOverrides": []
}
EOF

echo "[10/10] Parches aplicados exitosamente sobre el repositorio shamirdhc/alerta_desaparecidos."
