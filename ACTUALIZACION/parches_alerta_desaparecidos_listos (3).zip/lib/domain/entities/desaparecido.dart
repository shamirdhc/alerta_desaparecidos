import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:equatable/equatable.dart';

class Desaparecido extends Equatable {
  final String? id;
  final String nombres;
  final String apellidos;
  final String? sexo;
  final String? dni;
  final String? telefonoContacto;
  final DateTime? fechaNacimiento;
  final DateTime? fechaDesaparicion;
  final String? departamento;
  final String? provincia;
  final String? distrito;
  final String? detallesAdicionales;
  final String? _estado;
  final DateTime? fechaEncontrado;
  final String? fotoUrl;
  final String? imagenFichaUrl;
  final DateTime? fechaCreacion;
  final DateTime? fechaActualizacion;

  const Desaparecido({
    this.id,
    required this.nombres,
    required this.apellidos,
    this.sexo,
    this.dni,
    this.telefonoContacto,
    this.fechaNacimiento,
    this.fechaDesaparicion,
    this.departamento,
    this.provincia,
    this.distrito,
    this.detallesAdicionales,
    String? estado,
    this.fechaEncontrado,
    this.fotoUrl,
    this.imagenFichaUrl,
    this.fechaCreacion,
    this.fechaActualizacion,
  }) : _estado = estado ?? 'activo';

  String? get estado => _estado;

  Desaparecido copyWith({
    String? id,
    String? nombres,
    String? apellidos,
    String? sexo,
    String? dni,
    String? telefonoContacto,
    DateTime? fechaNacimiento,
    DateTime? fechaDesaparicion,
    String? departamento,
    String? provincia,
    String? distrito,
    String? detallesAdicionales,
    String? estado,
    DateTime? fechaEncontrado,
    String? fotoUrl,
    String? imagenFichaUrl,
    DateTime? fechaCreacion,
    DateTime? fechaActualizacion,
  }) {
    return Desaparecido(
      id: id ?? this.id,
      nombres: nombres ?? this.nombres,
      apellidos: apellidos ?? this.apellidos,
      sexo: sexo ?? this.sexo,
      dni: dni ?? this.dni,
      telefonoContacto: telefonoContacto ?? this.telefonoContacto,
      fechaNacimiento: fechaNacimiento ?? this.fechaNacimiento,
      fechaDesaparicion: fechaDesaparicion ?? this.fechaDesaparicion,
      departamento: departamento ?? this.departamento,
      provincia: provincia ?? this.provincia,
      distrito: distrito ?? this.distrito,
      detallesAdicionales: detallesAdicionales ?? this.detallesAdicionales,
      estado: estado ?? _estado,
      fechaEncontrado: fechaEncontrado ?? this.fechaEncontrado,
      fotoUrl: fotoUrl ?? this.fotoUrl,
      imagenFichaUrl: imagenFichaUrl ?? this.imagenFichaUrl,
      fechaCreacion: fechaCreacion ?? this.fechaCreacion,
      fechaActualizacion: fechaActualizacion ?? this.fechaActualizacion,
    );
  }

  static DateTime? _parseDate(dynamic value) {
    if (value == null) return null;
    if (value is Timestamp) return value.toDate();
    if (value is DateTime) return value;
    if (value is String) return DateTime.tryParse(value);
    return null;
  }

  Map<String, dynamic> toMap() {
    final fullLower = '${nombres.trim()} ${apellidos.trim()}'.toLowerCase();
    final effectiveFechaDesaparicion =
        fechaDesaparicion ?? fechaCreacion ?? DateTime.now();
    return {
      'nombres': nombres.trim(),
      'apellidos': apellidos.trim(),
      'nombre_lower': fullLower,
      'sexo': sexo,
      'dni': dni?.trim(),
      'telefono_contacto': telefonoContacto?.trim(),
      'fecha_nacimiento':
          fechaNacimiento != null ? Timestamp.fromDate(fechaNacimiento!) : null,
      'fecha_desaparicion': Timestamp.fromDate(effectiveFechaDesaparicion),
      'departamento': departamento,
      'provincia': provincia,
      'distrito': distrito,
      'detalles_adicionales': detallesAdicionales?.trim(),
      'estado': _estado ?? 'activo',
      'fecha_encontrado':
          fechaEncontrado != null ? Timestamp.fromDate(fechaEncontrado!) : null,
      'foto_url': fotoUrl,
      'imagen_ficha_url': imagenFichaUrl,
      'fecha_creacion': Timestamp.fromDate(fechaCreacion ?? DateTime.now()),
      'fecha_actualizacion':
          Timestamp.fromDate(fechaActualizacion ?? DateTime.now()),
    };
  }

  factory Desaparecido.fromMap(Map<String, dynamic> map, String? id) {
    return Desaparecido(
      id: id,
      nombres: (map['nombres'] ?? '').toString(),
      apellidos: (map['apellidos'] ?? '').toString(),
      sexo: map['sexo']?.toString(),
      dni: map['dni']?.toString(),
      telefonoContacto: map['telefono_contacto']?.toString(),
      fechaNacimiento: _parseDate(map['fecha_nacimiento']),
      fechaDesaparicion: _parseDate(map['fecha_desaparicion']) ??
          _parseDate(map['fecha_creacion']),
      departamento: map['departamento']?.toString(),
      provincia: map['provincia']?.toString(),
      distrito: map['distrito']?.toString(),
      detallesAdicionales: map['detalles_adicionales']?.toString(),
      estado: (map['estado'] ?? 'activo').toString(),
      fechaEncontrado: _parseDate(map['fecha_encontrado']),
      fotoUrl: (map['foto_url'] ?? map['fotoUrl'])?.toString(),
      imagenFichaUrl:
          (map['imagen_ficha_url'] ?? map['imagenFichaUrl'])?.toString(),
      fechaCreacion: _parseDate(map['fecha_creacion']),
      fechaActualizacion: _parseDate(map['fecha_actualizacion']),
    );
  }

  @override
  List<Object?> get props => [
        id,
        nombres,
        apellidos,
        sexo,
        dni,
        telefonoContacto,
        fechaNacimiento,
        fechaDesaparicion,
        departamento,
        provincia,
        distrito,
        detallesAdicionales,
        _estado,
        fechaEncontrado,
        fotoUrl,
        imagenFichaUrl,
        fechaCreacion,
        fechaActualizacion,
      ];
}
