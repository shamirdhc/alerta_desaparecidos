import 'dart:async';
import 'dart:typed_data';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:dartz/dartz.dart';
import 'package:firebase_storage/firebase_storage.dart';
import 'package:flutter_image_compress/flutter_image_compress.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../../common/failure.dart';
import '../../domain/entities/desaparecido.dart';
import '../../domain/enums.dart';

class DesaparecidoRemoteDataSource {
  final CollectionReference<Map<String, dynamic>> _desaparecidosCollection;
  final FirebaseStorage _storage;

  /// Intervalo mínimo (30 min) antes de volver a consultar deltas al servidor
  /// para proteger las 50,000 lecturas diarias del Plan Gratuito (Spark).
  static const int _kDeltaSyncCooldownMs = 30 * 60 * 1000;

  DesaparecidoRemoteDataSource(FirebaseFirestore firestore, this._storage)
      : _desaparecidosCollection = firestore.collection('desaparecidos');

  Future<Either<Failure, List<Desaparecido>>> getDesaparecidos({
    MissingFilter filter = MissingFilter.active,
    int? limit = 20,
    Desaparecido? lastDesaparecido,
    String? searchQuery,
    String? departamento,
  }) async {
    final cleanedQuery = searchQuery?.trim();
    if (cleanedQuery != null && cleanedQuery.isNotEmpty) {
      return _getDesaparecidosConBusquedaOr(
        filter: filter,
        limit: limit,
        searchQuery: cleanedQuery,
        departamento: departamento,
      );
    } else {
      return _getDesaparecidosSimple(
        filter: filter,
        limit: limit,
        lastDesaparecido: lastDesaparecido,
        departamento: departamento,
      );
    }
  }

  /// Estrategia "Cache-First + Delta Sync" para mantener el consumo en el Plan Free:
  /// 1. Si el dispositivo ya sincronizó en los últimos 30 min, lee 100% de la caché local (0 lecturas facturadas).
  /// 2. Si pasaron >30 min, descarga del servidor ÚNICAMENTE los casos cuya `fecha_actualizacion`
  ///    sea mayor a la última sincronización local y luego sirve la lista desde la caché local.
  Future<Either<Failure, List<Desaparecido>>> _getDesaparecidosSimple({
    required MissingFilter filter,
    int? limit,
    Desaparecido? lastDesaparecido,
    String? departamento,
  }) async {
    try {
      Query<Map<String, dynamic>> query = _buildBaseQuery(filter, departamento)
          .orderBy('fecha_desaparicion', descending: true);

      if (lastDesaparecido?.id != null) {
        try {
          final cachedCursor = await _desaparecidosCollection
              .doc(lastDesaparecido!.id)
              .get(const GetOptions(source: Source.cache));
          if (cachedCursor.exists) {
            query = query.startAfterDocument(cachedCursor);
          }
        } catch (_) {
          final serverCursor =
              await _desaparecidosCollection.doc(lastDesaparecido!.id).get();
          if (serverCursor.exists) {
            query = query.startAfterDocument(serverCursor);
          }
        }
      }

      if (limit != null) {
        query = query.limit(limit);
      }

      final prefs = await SharedPreferences.getInstance();
      final cacheKey = 'last_delta_sync_${filter.name}_${departamento ?? "ALL"}';
      final lastSyncMs = prefs.getInt(cacheKey) ?? 0;
      final nowMs = DateTime.now().millisecondsSinceEpoch;

      // Paso A: Intentar sincronizar solo los casos nuevos (Delta) si expiró el cooldown
      if (lastSyncMs > 0 && (nowMs - lastSyncMs) >= _kDeltaSyncCooldownMs) {
        try {
          final deltaQuery = _buildBaseQuery(filter, departamento)
              .where(
                'fecha_actualizacion',
                isGreaterThan: Timestamp.fromMillisecondsSinceEpoch(lastSyncMs),
              )
              .limit(50);
          // Al ejecutar .get() sobre el delta, Firestore actualiza automáticamente su caché local
          await deltaQuery.get(const GetOptions(source: Source.serverAndCache));
          await prefs.setInt(cacheKey, nowMs);
        } catch (_) {}
      }

      // Paso B: Intentar servir la página desde la caché local (0 lecturas de servidor)
      try {
        final cachedSnapshot =
            await query.get(const GetOptions(source: Source.cache));
        if (cachedSnapshot.docs.isNotEmpty) {
          final cachedList = await Future.wait(
            cachedSnapshot.docs.map(_mapDocToDesaparecido),
          );
          return Right(cachedList);
        }
      } catch (_) {}

      // Paso C: Primera carga (caché vacía) -> lee del servidor y guarda marca de tiempo
      final serverSnapshot =
          await query.get(const GetOptions(source: Source.serverAndCache));
      await prefs.setInt(cacheKey, nowMs);

      final desaparecidosList = await Future.wait(
        serverSnapshot.docs.map(_mapDocToDesaparecido),
      );
      return Right(desaparecidosList);
    } on FirebaseException catch (e) {
      return Left(DatabaseFailure('Error de Firestore (${e.code}): ${e.message}'));
    } catch (e) {
      return Left(DatabaseFailure('Error inesperado al obtener casos: $e'));
    }
  }

  Future<Either<Failure, List<Desaparecido>>> _getDesaparecidosConBusquedaOr({
    required MissingFilter filter,
    int? limit,
    required String searchQuery,
    String? departamento,
  }) async {
    try {
      final queryLower = searchQuery.toLowerCase();

      Query<Map<String, dynamic>> queryNombre = _buildBaseQuery(filter, departamento)
          .where('nombre_lower', isGreaterThanOrEqualTo: queryLower)
          .where('nombre_lower', isLessThanOrEqualTo: '$queryLower\uf8ff');
      if (limit != null) queryNombre = queryNombre.limit(limit);

      Query<Map<String, dynamic>> queryDni = _buildBaseQuery(filter, departamento)
          .where('dni', isGreaterThanOrEqualTo: searchQuery)
          .where('dni', isLessThanOrEqualTo: '$searchQuery\uf8ff');
      if (limit != null) queryDni = queryDni.limit(limit);

      final results = await Future.wait([queryNombre.get(), queryDni.get()]);
      final Map<String, Desaparecido> desaparecidosMap = {};

      for (var doc in results[0].docs) {
        final item = await _mapDocToDesaparecido(doc);
        if (item.id != null) desaparecidosMap[item.id!] = item;
      }
      for (var doc in results[1].docs) {
        if (!desaparecidosMap.containsKey(doc.id)) {
          final item = await _mapDocToDesaparecido(doc);
          if (item.id != null) desaparecidosMap[item.id!] = item;
        }
      }

      List<Desaparecido> list = desaparecidosMap.values.toList();
      final epoch = DateTime.fromMillisecondsSinceEpoch(0);
      list.sort((a, b) {
        final dateA = a.fechaDesaparicion ?? a.fechaCreacion ?? epoch;
        final dateB = b.fechaDesaparicion ?? b.fechaCreacion ?? epoch;
        return dateB.compareTo(dateA);
      });

      if (limit != null && list.length > limit) {
        list = list.sublist(0, limit);
      }
      return Right(list);
    } on FirebaseException catch (e) {
      return Left(DatabaseFailure('Error de Firestore (${e.code}): ${e.message}'));
    } catch (e) {
      return Left(DatabaseFailure('Error al buscar casos: $e'));
    }
  }

  Query<Map<String, dynamic>> _buildBaseQuery(
    MissingFilter filter,
    String? departamento,
  ) {
    Query<Map<String, dynamic>> query = _desaparecidosCollection;

    switch (filter) {
      case MissingFilter.active:
        query = query.where('estado', isEqualTo: 'activo');
        break;
      case MissingFilter.found:
        query = query.where('estado', isEqualTo: 'encontrado');
        break;
      case MissingFilter.all:
        break;
    }

    if (departamento != null && departamento.trim().isNotEmpty) {
      query = query.where('departamento', isEqualTo: departamento.trim());
    }

    return query;
  }

  Future<Desaparecido> _mapDocToDesaparecido(
    DocumentSnapshot<Map<String, dynamic>> doc,
  ) async {
    final data = doc.data() ?? <String, dynamic>{};
    final base = Desaparecido.fromMap(data, doc.id);

    if (base.departamento != null && base.departamento!.isNotEmpty) {
      return base;
    }

    try {
      final ubicacionDoc =
          await doc.reference.collection('ubicacion').doc('detalles').get();
      if (ubicacionDoc.exists && ubicacionDoc.data() != null) {
        final u = ubicacionDoc.data()!;
        return base.copyWith(
          departamento: u['departamento']?.toString() ?? base.departamento,
          provincia: u['provincia']?.toString() ?? base.provincia,
          distrito: u['distrito']?.toString() ?? base.distrito,
        );
      }
    } catch (_) {}

    return base;
  }

  Future<Either<Failure, String>> uploadImage(
    String path,
    Uint8List imageBytes,
  ) async {
    Uint8List payload = imageBytes;
    try {
      payload = await FlutterImageCompress.compressWithList(
        imageBytes,
        minWidth: 1080,
        minHeight: 1080,
        quality: 78,
        format: CompressFormat.webp,
      );
    } catch (_) {
      payload = imageBytes;
    }

    if (payload.lengthInBytes > 5 * 1024 * 1024) {
      return Left(DatabaseFailure('La fotografía supera el límite máximo de 5 MB.'));
    }

    int attempt = 0;
    while (true) {
      try {
        attempt++;
        final Reference storageRef = _storage.ref().child(path);
        final metadata = SettableMetadata(
          contentType: 'image/webp',
          cacheControl: 'public, max-age=31536000, immutable',
        );
        final TaskSnapshot snapshot = await storageRef
            .putData(payload, metadata)
            .timeout(const Duration(seconds: 25));
        final String downloadUrl = await snapshot.ref.getDownloadURL();
        return Right(downloadUrl);
      } on FirebaseException catch (e) {
        if (attempt >= 3) {
          return Left(DatabaseFailure(e.message ?? 'Error al subir la fotografía.'));
        }
        await Future.delayed(Duration(seconds: 1 << (attempt - 1)));
      } catch (e) {
        if (attempt >= 3) {
          return Left(DatabaseFailure('Fallo de red al subir imagen: $e'));
        }
        await Future.delayed(Duration(seconds: 1 << (attempt - 1)));
      }
    }
  }

  Future<Either<Failure, void>> reportarDesaparecido(
    Desaparecido desaparecido, {
    Uint8List? fotoBytes,
    Uint8List? fichaBytes,
  }) async {
    try {
      final DocumentReference<Map<String, dynamic>> docRef =
          (desaparecido.id != null && desaparecido.id!.isNotEmpty)
              ? _desaparecidosCollection.doc(desaparecido.id)
              : _desaparecidosCollection.doc();

      String? fotoUrl = desaparecido.fotoUrl;
      String? fichaUrl = desaparecido.imagenFichaUrl;

      if (fotoBytes != null) {
        final fotoResult = await uploadImage(
          'desaparecidos/${docRef.id}/foto.webp',
          fotoBytes,
        );
        fotoResult.fold((l) => throw Exception(l.message), (r) => fotoUrl = r);
      }

      if (fichaBytes != null) {
        final fichaResult = await uploadImage(
          'desaparecidos/${docRef.id}/ficha.webp',
          fichaBytes,
        );
        fichaResult.fold((l) => throw Exception(l.message), (r) => fichaUrl = r);
      }

      final recordToSave = desaparecido.copyWith(
        id: docRef.id,
        fotoUrl: fotoUrl,
        imagenFichaUrl: fichaUrl,
        fechaCreacion: desaparecido.fechaCreacion ?? DateTime.now(),
        fechaActualizacion: DateTime.now(),
      );

      await docRef.set(recordToSave.toMap());
      return const Right(null);
    } on FirebaseException catch (e) {
      return Left(DatabaseFailure(e.message ?? 'Error al guardar el reporte en Firestore.'));
    } catch (e) {
      return Left(DatabaseFailure(e.toString()));
    }
  }

  Future<Either<Failure, void>> marcarComoEncontrado(
    String desaparecidoId,
  ) async {
    try {
      await _desaparecidosCollection.doc(desaparecidoId).update({
        'estado': 'encontrado',
        'fecha_encontrado': FieldValue.serverTimestamp(),
        'fecha_actualizacion': FieldValue.serverTimestamp(),
      });
      return const Right(null);
    } on FirebaseException catch (e) {
      return Left(DatabaseFailure(e.message ?? 'Error al marcar como encontrado.'));
    } catch (e) {
      return Left(DatabaseFailure(e.toString()));
    }
  }
}
