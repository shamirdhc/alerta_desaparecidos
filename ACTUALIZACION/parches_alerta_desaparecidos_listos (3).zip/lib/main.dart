import 'dart:async';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_app_check/firebase_app_check.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'firebase_options.dart';
import 'package:alerta_desaparecidos/injection.dart' as di;
import 'package:alerta_desaparecidos/common/styles/app_theme.dart';
import 'package:alerta_desaparecidos/presentation/citizen/screens/citizen_home_screen.dart';
import 'package:alerta_desaparecidos/presentation/common/loading_screen.dart';
import 'package:alerta_desaparecidos/presentation/police/screens/police_home_screen.dart';
import 'package:alerta_desaparecidos/presentation/police/view_models/add_missing_view_model.dart';
import 'package:alerta_desaparecidos/presentation/police/view_models/manage_missing_view_model.dart';
import 'package:alerta_desaparecidos/presentation/citizen/view_models/view_missing_view_model.dart';
import 'package:alerta_desaparecidos/presentation/screens/registration_screen.dart';

const String _kRecaptchaSiteKey = String.fromEnvironment(
  'RECAPTCHA_ENTERPRISE_SITE_KEY',
  defaultValue: '',
);

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform);

  // 1. FIX CRÍTICO PARA iPHONE (Safari / WebKit ITP y Modo Privado):
  // Garantiza persistencia de sesión en iOS Web y consume cualquier redirect pendiente
  if (kIsWeb) {
    try {
      await FirebaseAuth.instance.setPersistence(Persistence.LOCAL);
    } catch (_) {
      // Fallback para Safari en Navegación Privada en iPhone (donde indexedDB está restringido)
      try {
        await FirebaseAuth.instance.setPersistence(Persistence.SESSION);
      } catch (_) {}
    }
    try {
      await FirebaseAuth.instance.getRedirectResult();
    } catch (e) {
      debugPrint('[iOS Web Redirect Info] $e');
    }
  }

  // 2. Activar Firebase App Check si está configurado
  if (!kIsWeb || _kRecaptchaSiteKey.isNotEmpty) {
    try {
      await FirebaseAppCheck.instance.activate(
        webProvider: ReCaptchaEnterpriseProvider(_kRecaptchaSiteKey),
        androidProvider:
            kDebugMode ? AndroidProvider.debug : AndroidProvider.playIntegrity,
        appleProvider:
            kDebugMode ? AppleProvider.debug : AppleProvider.appAttest,
      );
    } catch (e) {
      debugPrint('[AppCheck] Aviso de inicialización: $e');
    }
  }

  // 3. Habilitar caché offline en Firestore (con fallback seguro para Safari iOS)
  try {
    FirebaseFirestore.instance.settings = const Settings(
      persistenceEnabled: true,
      cacheSizeBytes: Settings.CACHE_SIZE_UNLIMITED,
    );
  } catch (_) {}

  // 4. Manejo global de errores (Error Boundary)
  FlutterError.onError = (FlutterErrorDetails details) {
    FlutterError.presentError(details);
  };
  PlatformDispatcher.instance.onError = (Object error, StackTrace stack) {
    debugPrint('[AsyncError] $error\n$stack');
    return true;
  };

  di.init();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => di.locator<AddMissingViewModel>()),
        ChangeNotifierProvider(create: (_) => di.locator<ManageMissingViewModel>()),
        ChangeNotifierProvider(create: (_) => di.locator<ViewMissingViewModel>()),
      ],
      child: MaterialApp(
        title: 'Alerta Desaparecidos PNP',
        debugShowCheckedModeBanner: false,
        theme: AppTheme.lightTheme,
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        supportedLocales: const [
          Locale('es', 'ES'),
          Locale('en', 'US'),
        ],
        locale: const Locale('es', 'ES'),
        home: const AuthGateScreen(),
        routes: {
          '/registration': (context) => const RegistrationScreen(),
          '/registro': (context) => const RegistrationScreen(),
          '/citizen_home': (context) => const CitizenHomeScreen(),
          '/ciudadano_home': (context) => const CitizenHomeScreen(),
          '/police_home': (context) => const PoliceHomeScreen(),
          '/policia_home': (context) => const PoliceHomeScreen(),
        },
      ),
    );
  }
}

/// Widget guardián de sesión que resuelve el bug de iPhone donde el usuario
/// era devuelto a RegistrationScreen después de iniciar sesión.
/// Causa original: main.dart sólo revisaba `claims['role']` (que era null) y
/// re-ejecutaba `getIdTokenResult(true)` en cada cambio de métricas de pantalla en iOS.
class AuthGateScreen extends StatefulWidget {
  const AuthGateScreen({super.key});

  @override
  State<AuthGateScreen> createState() => _AuthGateScreenState();
}

class _AuthGateScreenState extends State<AuthGateScreen> {
  String? _cachedUid;
  Future<String>? _roleFuture;

  Future<String> _resolveAndEnsureUserRole(User user) async {
    final prefs = await SharedPreferences.getInstance();

    // 1. Revisar Custom Claims en el token JWT (sin forzar red si no es necesario)
    try {
      final tokenResult = await user.getIdTokenResult(false);
      final claimRole = tokenResult.claims?['role']?.toString();
      if (claimRole == 'police' || claimRole == 'superadmin') {
        await prefs.setString('cached_role_${user.uid}', 'police');
        return 'police';
      }
      if (claimRole == 'citizen') {
        await prefs.setString('cached_role_${user.uid}', 'citizen');
        return 'citizen';
      }
    } catch (_) {}

    // 2. Revisar colección 'policias' por UID o por número de teléfono
    try {
      final policeDocByUid = await FirebaseFirestore.instance
          .collection('policias')
          .doc(user.uid)
          .get();
      if (policeDocByUid.exists) {
        await prefs.setString('cached_role_${user.uid}', 'police');
        return 'police';
      }

      if (user.phoneNumber != null && user.phoneNumber!.isNotEmpty) {
        final policeQuery = await FirebaseFirestore.instance
            .collection('policias')
            .where('telefono', isEqualTo: user.phoneNumber)
            .limit(1)
            .get();
        if (policeQuery.docs.isNotEmpty) {
          await prefs.setString('cached_role_${user.uid}', 'police');
          return 'police';
        }
      }
    } catch (_) {}

    // 3. Revisar o auto-crear perfil en colección 'ciudadanos' (Evita Race Condition en iPhone)
    try {
      final citizenRef =
          FirebaseFirestore.instance.collection('ciudadanos').doc(user.uid);
      final citizenDoc = await citizenRef.get();
      if (citizenDoc.exists) {
        await prefs.setString('cached_role_${user.uid}', 'citizen');
        return 'citizen';
      }

      // Si el usuario ya se autenticó con Firebase Auth (OTP o Google en iPhone)
      // pero la escritura de otp_screen aún está en vuelo o fue interrumpida por Safari,
      // aseguramos el documento automáticamente en lugar de devolverlo al Login:
      await citizenRef.set({
        'uid': user.uid,
        'telefono': user.phoneNumber ?? '',
        'email': user.email ?? '',
        'rol': 'ciudadano',
        'fecha_registro': FieldValue.serverTimestamp(),
      }, SetOptions(merge: true));

      await prefs.setString('cached_role_${user.uid}', 'citizen');
      return 'citizen';
    } catch (_) {
      // Si la red falla momentáneamente en iPhone tras el login, usar rol cacheado o 'citizen'
      return prefs.getString('cached_role_${user.uid}') ?? 'citizen';
    }
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<User?>(
      stream: FirebaseAuth.instance.authStateChanges(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting &&
            _cachedUid == null) {
          return const LoadingScreen();
        }

        final user = snapshot.data ?? FirebaseAuth.instance.currentUser;
        if (user == null) {
          _cachedUid = null;
          _roleFuture = null;
          return const RegistrationScreen();
        }

        // Memoizar el Future por UID para que cuando iOS cierre el teclado o cambie
        // la barra de Safari no se dispare un bucle de recarga al Login
        if (_cachedUid != user.uid || _roleFuture == null) {
          _cachedUid = user.uid;
          _roleFuture = _resolveAndEnsureUserRole(user);
        }

        return FutureBuilder<String>(
          future: _roleFuture,
          builder: (context, roleSnapshot) {
            if (roleSnapshot.connectionState == ConnectionState.waiting) {
              return const LoadingScreen();
            }
            final role = roleSnapshot.data ?? 'citizen';
            if (role == 'police') {
              return const PoliceHomeScreen();
            }
            return const CitizenHomeScreen();
          },
        );
      },
    );
  }
}
