import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'otp_screen.dart';

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({super.key});

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final TextEditingController _phoneController = TextEditingController();
  ConfirmationResult? _webConfirmationResult;
  String? _errorMessage;
  bool _isRegistering = false;

  @override
  void dispose() {
    _phoneController.dispose();
    super.dispose();
  }

  Future<bool> _isNumberVetoed(String phoneNumber) async {
    try {
      final snapshot = await FirebaseFirestore.instance
          .collection('vetados')
          .where('numero_telefono', isEqualTo: phoneNumber)
          .limit(1)
          .get();
      return snapshot.docs.isNotEmpty;
    } catch (_) {
      // Si las reglas de Firestore bloquean lectura anónima o falla la red, no bloquear el acceso
      return false;
    }
  }

  Future<void> _registerUser(String phoneNumber) async {
    try {
      // Soporte específico para Web (incluyendo Safari en iPhone) vs Nativo (iOS/Android)
      if (kIsWeb) {
        _webConfirmationResult =
            await FirebaseAuth.instance.signInWithPhoneNumber(phoneNumber);
        if (!mounted) return;
        setState(() => _isRegistering = false);
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (context) => OTPScreen(
              phoneNumber: phoneNumber,
              verificationId: _webConfirmationResult!.verificationId,
              webConfirmationResult: _webConfirmationResult,
            ),
          ),
        );
        return;
      }

      await FirebaseAuth.instance.verifyPhoneNumber(
        phoneNumber: phoneNumber,
        timeout: const Duration(seconds: 60),
        verificationCompleted: (PhoneAuthCredential credential) async {
          try {
            await FirebaseAuth.instance.signInWithCredential(credential);
          } catch (_) {}
        },
        verificationFailed: (FirebaseAuthException e) {
          if (!mounted) return;
          setState(() {
            _errorMessage =
                'Error al enviar el código de verificación: ${e.message ?? e.code}';
            _isRegistering = false;
          });
        },
        codeSent: (String verificationId, int? resendToken) {
          if (!mounted) return;
          setState(() => _isRegistering = false);
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (context) => OTPScreen(
                phoneNumber: phoneNumber,
                verificationId: verificationId,
              ),
            ),
          );
        },
        codeAutoRetrievalTimeout: (String verificationId) {
          if (!mounted) return;
          setState(() => _isRegistering = false);
        },
      );
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _errorMessage = 'Error durante el inicio de sesión: $e';
        _isRegistering = false;
      });
    }
  }

  Future<void> _registerOrLogin() async {
    final rawPhone = _phoneController.text.replaceAll(RegExp(r'\D'), '');
    if (rawPhone.length != 9) {
      setState(() {
        _errorMessage = 'Ingresa un número de celular válido de 9 dígitos.';
      });
      return;
    }

    setState(() {
      _errorMessage = null;
      _isRegistering = true;
    });

    final String phoneNumber = '+51$rawPhone';

    if (await _isNumberVetoed(phoneNumber)) {
      if (!mounted) return;
      setState(() {
        _errorMessage =
            'El número de teléfono proporcionado ha sido restringido por infringir los términos del servicio.';
        _isRegistering = false;
      });
      return;
    }

    await _registerUser(phoneNumber);
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      // Permite cerrar el teclado en iPhone al tocar fuera del campo de texto
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: AppBar(title: const Text('Ingreso — Alerta Desaparecidos PNP')),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                TextField(
                  controller: _phoneController,
                  keyboardType: TextInputType.phone,
                  textInputAction: TextInputAction.done,
                  maxLength: 9,
                  onSubmitted: (_) => _isRegistering ? null : _registerOrLogin(),
                  decoration: const InputDecoration(
                    labelText: 'Número de Celular (Ej: 987654321)',
                    prefixText: '+51 ',
                    border: OutlineInputBorder(),
                  ),
                ),
                if (_errorMessage != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 10.0),
                    child: Text(
                      _errorMessage!,
                      style: const TextStyle(color: Colors.red),
                    ),
                  ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _isRegistering ? null : _registerOrLogin,
                  child: Text(_isRegistering ? 'Verificando...' : 'Continuar'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
