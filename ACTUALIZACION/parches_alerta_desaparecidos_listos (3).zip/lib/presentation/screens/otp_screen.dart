import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../citizen/screens/citizen_home_screen.dart';
import '../police/screens/police_home_screen.dart';

class OTPScreen extends StatefulWidget {
  final String phoneNumber;
  final String verificationId;
  final ConfirmationResult? webConfirmationResult;

  const OTPScreen({
    super.key,
    required this.phoneNumber,
    required this.verificationId,
    this.webConfirmationResult,
  });

  @override
  State<OTPScreen> createState() => _OTPScreenState();
}

class _OTPScreenState extends State<OTPScreen> {
  final TextEditingController _otpController = TextEditingController();
  String? _errorMessage;
  bool _verifying = false;

  @override
  void dispose() {
    _otpController.dispose();
    super.dispose();
  }

  Future<bool> _isNumberInPoliceCollection(String uid, String phoneNumber) async {
    try {
      final docByUid = await FirebaseFirestore.instance
          .collection('policias')
          .doc(uid)
          .get();
      if (docByUid.exists) return true;

      final snapshot = await FirebaseFirestore.instance
          .collection('policias')
          .where('telefono', isEqualTo: phoneNumber)
          .limit(1)
          .get();
      return snapshot.docs.isNotEmpty;
    } catch (_) {
      return false;
    }
  }

  Future<void> _createUserFirestore(String uid, String phoneNumber) async {
    await FirebaseFirestore.instance.collection('ciudadanos').doc(uid).set({
      'telefono': phoneNumber,
      'rol': 'ciudadano',
      'fecha_registro': FieldValue.serverTimestamp(),
      'uid': uid,
    }, SetOptions(merge: true));
  }

  Future<void> _verifyOTPAndNavigate() async {
    final code = _otpController.text.trim();
    if (code.length < 6) {
      setState(() {
        _errorMessage = 'Ingresa los 6 dígitos del código de verificación.';
      });
      return;
    }

    setState(() {
      _errorMessage = null;
      _verifying = true;
    });

    try {
      UserCredential userCredential;
      if (widget.webConfirmationResult != null) {
        userCredential = await widget.webConfirmationResult!.confirm(code);
      } else {
        final credential = PhoneAuthProvider.credential(
          verificationId: widget.verificationId,
          smsCode: code,
        );
        userCredential =
            await FirebaseAuth.instance.signInWithCredential(credential);
      }

      final User? user = userCredential.user;
      if (user == null) {
        if (!mounted) return;
        setState(() {
          _errorMessage = 'No se pudo obtener la sesión del usuario.';
          _verifying = false;
        });
        return;
      }

      final prefs = await SharedPreferences.getInstance();
      final isPolice =
          await _isNumberInPoliceCollection(user.uid, widget.phoneNumber);

      if (isPolice) {
        await prefs.setString('cached_role_${user.uid}', 'police');
        if (!mounted) return;
        // Limpia toda la pila de navegación en iOS para que no regrese a RegistrationScreen
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const PoliceHomeScreen()),
          (route) => false,
        );
      } else {
        try {
          await _createUserFirestore(user.uid, widget.phoneNumber);
        } catch (e) {
          debugPrint('[OTP] Aviso guardando perfil ciudadano: $e');
        }
        await prefs.setString('cached_role_${user.uid}', 'citizen');
        if (!mounted) return;
        Navigator.of(context).pushAndRemoveUntil(
          MaterialPageRoute(builder: (_) => const CitizenHomeScreen()),
          (route) => false,
        );
      }
    } on FirebaseAuthException catch (e) {
      if (!mounted) return;
      setState(() {
        _errorMessage = 'Código OTP inválido o expirado: ${e.message ?? e.code}';
        _verifying = false;
      });
    } catch (e) {
      if (!mounted) return;
      setState(() {
        _errorMessage = 'Ocurrió un error al verificar el código: $e';
        _verifying = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => FocusScope.of(context).unfocus(),
      child: Scaffold(
        appBar: AppBar(title: const Text('Verificar Código SMS')),
        body: SafeArea(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: <Widget>[
                Text('Se envió un código de 6 dígitos a ${widget.phoneNumber}'),
                const SizedBox(height: 12),
                TextField(
                  controller: _otpController,
                  keyboardType: TextInputType.number,
                  // Habilita autocompletado nativo de SMS en iPhone (iOS One-Time Code)
                  autofillHints: const [AutofillHints.oneTimeCode],
                  maxLength: 6,
                  onSubmitted: (_) => _verifying ? null : _verifyOTPAndNavigate(),
                  decoration: const InputDecoration(
                    labelText: 'Código OTP',
                    border: OutlineInputBorder(),
                  ),
                ),
                if (_errorMessage != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 10.0),
                    child: Text(
                      _errorMessage!,
                      style: const TextStyle(color: Colors.red),
                    ),
                  ),
                const SizedBox(height: 20),
                ElevatedButton(
                  onPressed: _verifying ? null : _verifyOTPAndNavigate,
                  child: Text(_verifying ? 'Verificando...' : 'Verificar e Ingresar'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
