// File generated and hardened for Multiplatform + iOS Safari ITP compatibility.
// ignore_for_file: type=lint
import 'package:firebase_core/firebase_core.dart' show FirebaseOptions;
import 'package:flutter/foundation.dart'
    show defaultTargetPlatform, kIsWeb, TargetPlatform;

class DefaultFirebaseOptions {
  static FirebaseOptions get currentPlatform {
    if (kIsWeb) {
      return web;
    }
    switch (defaultTargetPlatform) {
      case TargetPlatform.android:
        return android;
      case TargetPlatform.iOS:
        return ios;
      case TargetPlatform.macOS:
        return ios;
      case TargetPlatform.windows:
        return windows;
      default:
        throw UnsupportedError(
          'DefaultFirebaseOptions are not supported for this platform.',
        );
    }
  }

  /// En iPhone (Safari / WebKit ITP), si authDomain difiere del dominio actual
  /// (ej. pnpalerta.web.app vs alerta-desaparecidos-pnp.firebaseapp.com),
  /// Safari bloquea sessionStorage/cookies de terceros y devuelve al usuario al Login.
  static String get _resolvedWebAuthDomain {
    if (kIsWeb) {
      final host = Uri.base.host;
      if (host.endsWith('.web.app') || host.endsWith('.firebaseapp.com')) {
        return host;
      }
    }
    return 'alerta-desaparecidos-pnp.firebaseapp.com';
  }

  static FirebaseOptions get web => FirebaseOptions(
        apiKey: 'AIzaSyD0hbcfgvjzAKyNw0k81_-3y1wGbX3rogM',
        appId: '1:75698715605:web:a77a01a49471b69d151b5c',
        messagingSenderId: '75698715605',
        projectId: 'alerta-desaparecidos-pnp',
        authDomain: _resolvedWebAuthDomain,
        storageBucket: 'alerta-desaparecidos-pnp.firebasestorage.app',
      );

  static const FirebaseOptions android = FirebaseOptions(
    apiKey: 'AIzaSyBw_kcfAG4V4TDJ3T-yhV1MbP8jKGWy2eM',
    appId: '1:75698715605:android:0457d3e14a710c5c151b5c',
    messagingSenderId: '75698715605',
    projectId: 'alerta-desaparecidos-pnp',
    storageBucket: 'alerta-desaparecidos-pnp.firebasestorage.app',
  );

  static const FirebaseOptions ios = FirebaseOptions(
    apiKey: 'AIzaSyCyMnR9Jdkd6xHYrNMcdB2w_WOysCMp3wQ',
    appId: '1:75698715605:ios:99a336d9f0e533db151b5c',
    messagingSenderId: '75698715605',
    projectId: 'alerta-desaparecidos-pnp',
    storageBucket: 'alerta-desaparecidos-pnp.firebasestorage.app',
    iosBundleId: 'com.shamirdhc.alertaDesaparecidos',
  );

  static const FirebaseOptions windows = FirebaseOptions(
    apiKey: 'AIzaSyD0hbcfgvjzAKyNw0k81_-3y1wGbX3rogM',
    appId: '1:75698715605:web:25fe2de4fc75b680151b5c',
    messagingSenderId: '75698715605',
    projectId: 'alerta-desaparecidos-pnp',
    authDomain: 'alerta-desaparecidos-pnp.firebaseapp.com',
    storageBucket: 'alerta-desaparecidos-pnp.firebasestorage.app',
  );
}
